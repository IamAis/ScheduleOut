# Overview

ScheduleOut is a fitness coaching platform built with React and Express.js that connects coaches with clients for workout management and scheduling. The application enables coaches to create workout plans, assign them to clients, and manage training schedules, while clients can view their assigned workouts and track their progress.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
- **React 18** with TypeScript for the client-side application
- **Vite** as the build tool and development server with hot module replacement
- **TailwindCSS** for styling with custom CSS variables for theming
- **Shadcn/ui** component library for consistent UI components
- **Wouter** for client-side routing (lightweight React Router alternative)
- **React Hook Form** with Zod validation for form management
- **TanStack Query** for server state management and caching

## Backend Architecture
- **Express.js** server with TypeScript
- **Minimal REST API** approach - most data operations handled directly via Supabase client
- **Development-focused Vite integration** for seamless full-stack development
- **Error handling middleware** with structured logging

## Database Design
- **PostgreSQL** database with Drizzle ORM for type-safe database operations
- **Schema includes**:
  - Users (coaches and clients with role-based differentiation)
  - Workout plans with JSON-based exercise storage
  - Client-coach relationships for access control
  - Workout assignments linking plans to clients
  - Scheduled sessions for calendar management
- **UUID primary keys** for all entities
- **Timestamps** for audit trails

## Authentication & Authorization
- **Supabase Auth** for user authentication and session management
- **Role-based access control** (coach vs client permissions)
- **React Context** for global auth state management
- **Protected routes** with automatic redirects based on auth status

## State Management
- **React Context** for authentication state
- **TanStack Query** for server state with optimistic updates
- **React Hook Form** for form state with validation
- **Local component state** for UI interactions

## Styling Architecture
- **TailwindCSS** with custom design system
- **CSS custom properties** for theme variables
- **Dark mode support** built into the design system
- **Responsive design** with mobile-first approach
- **Component-based styling** with shadcn/ui patterns

# External Dependencies

## Database & Backend Services
- **Supabase** - Primary database hosting and authentication provider
- **Neon Database** (alternative) - PostgreSQL hosting with serverless capabilities
- **Drizzle ORM** - Type-safe database client and migration management

## UI & Styling
- **Radix UI** - Headless component primitives for accessibility
- **TailwindCSS** - Utility-first CSS framework
- **Lucide React** - Icon library for consistent iconography
- **Class Variance Authority** - Utility for component variant management

## Development Tools
- **TypeScript** - Type safety across the entire application
- **Vite** - Fast build tool and development server
- **ESBuild** - Fast JavaScript bundler for production builds
- **PostCSS** - CSS processing for TailwindCSS

## Form & Data Management
- **React Hook Form** - Performant form library with validation
- **Zod** - Schema validation for type-safe data handling
- **Date-fns** - Date manipulation and formatting utilities

## Development Environment
- **Replit** - Cloud development platform with custom plugins
- **Node.js** - Runtime environment for the Express server
- **NPM** - Package management and dependency resolution