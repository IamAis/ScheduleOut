import { sql } from "drizzle-orm";
import { pgTable, text, varchar, timestamp, integer, boolean, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  email: text("email").notNull().unique(),
  password: text("password").notNull(),
  firstName: text("first_name").notNull(),
  lastName: text("last_name").notNull(),
  role: text("role").notNull().$type<"coach" | "client">(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const workoutPlans = pgTable("workout_plans", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  coachId: varchar("coach_id").notNull().references(() => users.id),
  name: text("name").notNull(),
  description: text("description"),
  duration: integer("duration").notNull(), // in minutes
  difficulty: text("difficulty").notNull().$type<"beginner" | "intermediate" | "advanced">(),
  exercises: jsonb("exercises").notNull().$type<Array<{
    name: string;
    sets: string;
    rest: string;
  }>>(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const clientCoachRelations = pgTable("client_coach_relations", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  clientId: varchar("client_id").notNull().references(() => users.id),
  coachId: varchar("coach_id").notNull().references(() => users.id),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const workoutAssignments = pgTable("workout_assignments", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  workoutPlanId: varchar("workout_plan_id").notNull().references(() => workoutPlans.id),
  clientId: varchar("client_id").notNull().references(() => users.id),
  coachId: varchar("coach_id").notNull().references(() => users.id),
  assignedAt: timestamp("assigned_at").defaultNow().notNull(),
});

export const scheduledSessions = pgTable("scheduled_sessions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  workoutPlanId: varchar("workout_plan_id").notNull().references(() => workoutPlans.id),
  clientId: varchar("client_id").notNull().references(() => users.id),
  coachId: varchar("coach_id").notNull().references(() => users.id),
  scheduledDate: timestamp("scheduled_date").notNull(),
  completed: boolean("completed").default(false).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
});

export const insertWorkoutPlanSchema = createInsertSchema(workoutPlans).omit({
  id: true,
  createdAt: true,
});

export const insertClientCoachRelationSchema = createInsertSchema(clientCoachRelations).omit({
  id: true,
  createdAt: true,
});

export const insertWorkoutAssignmentSchema = createInsertSchema(workoutAssignments).omit({
  id: true,
  assignedAt: true,
});

export const insertScheduledSessionSchema = createInsertSchema(scheduledSessions).omit({
  id: true,
  createdAt: true,
});

export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type WorkoutPlan = typeof workoutPlans.$inferSelect;
export type InsertWorkoutPlan = z.infer<typeof insertWorkoutPlanSchema>;
export type ClientCoachRelation = typeof clientCoachRelations.$inferSelect;
export type InsertClientCoachRelation = z.infer<typeof insertClientCoachRelationSchema>;
export type WorkoutAssignment = typeof workoutAssignments.$inferSelect;
export type InsertWorkoutAssignment = z.infer<typeof insertWorkoutAssignmentSchema>;
export type ScheduledSession = typeof scheduledSessions.$inferSelect;
export type InsertScheduledSession = z.infer<typeof insertScheduledSessionSchema>;
