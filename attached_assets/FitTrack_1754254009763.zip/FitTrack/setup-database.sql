-- ScheduleOut Database Setup
-- Run this SQL in your Supabase SQL Editor

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Users table (profiles for authenticated users)
CREATE TABLE IF NOT EXISTS users (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  email TEXT NOT NULL UNIQUE,
  password TEXT NOT NULL DEFAULT '',
  first_name TEXT NOT NULL,
  last_name TEXT NOT NULL,
  role TEXT NOT NULL CHECK (role IN ('coach', 'client')),
  created_at TIMESTAMP DEFAULT NOW()
);

-- Workout Plans table
CREATE TABLE IF NOT EXISTS workout_plans (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  coach_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  description TEXT,
  duration INTEGER NOT NULL, -- in minutes
  difficulty TEXT NOT NULL CHECK (difficulty IN ('beginner', 'intermediate', 'advanced')),
  exercises JSONB NOT NULL DEFAULT '[]',
  created_at TIMESTAMP DEFAULT NOW()
);

-- Client-Coach Relationships table
CREATE TABLE IF NOT EXISTS client_coach_relations (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  client_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  coach_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  created_at TIMESTAMP DEFAULT NOW(),
  UNIQUE(client_id, coach_id)
);

-- Workout Assignments table
CREATE TABLE IF NOT EXISTS workout_assignments (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  workout_plan_id UUID NOT NULL REFERENCES workout_plans(id) ON DELETE CASCADE,
  client_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  coach_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  assigned_at TIMESTAMP DEFAULT NOW()
);

-- Scheduled Sessions table
CREATE TABLE IF NOT EXISTS scheduled_sessions (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  workout_plan_id UUID NOT NULL REFERENCES workout_plans(id) ON DELETE CASCADE,
  client_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  coach_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  scheduled_date TIMESTAMP NOT NULL,
  completed BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMP DEFAULT NOW()
);

-- Row Level Security (RLS) Policies
ALTER TABLE users ENABLE ROW LEVEL SECURITY;
ALTER TABLE workout_plans ENABLE ROW LEVEL SECURITY;
ALTER TABLE client_coach_relations ENABLE ROW LEVEL SECURITY;
ALTER TABLE workout_assignments ENABLE ROW LEVEL SECURITY;
ALTER TABLE scheduled_sessions ENABLE ROW LEVEL SECURITY;

-- Users can read their own profile
CREATE POLICY "Users can view own profile" ON users
FOR SELECT USING (auth.uid()::text = id::text);

-- Users can update their own profile
CREATE POLICY "Users can update own profile" ON users
FOR UPDATE USING (auth.uid()::text = id::text);

-- Coaches can view their workout plans
CREATE POLICY "Coaches can view own workout plans" ON workout_plans
FOR SELECT USING (auth.uid()::text = coach_id::text);

-- Coaches can create workout plans
CREATE POLICY "Coaches can create workout plans" ON workout_plans
FOR INSERT WITH CHECK (auth.uid()::text = coach_id::text);

-- Coaches can update their workout plans
CREATE POLICY "Coaches can update own workout plans" ON workout_plans
FOR UPDATE USING (auth.uid()::text = coach_id::text);

-- Coaches can delete their workout plans
CREATE POLICY "Coaches can delete own workout plans" ON workout_plans
FOR DELETE USING (auth.uid()::text = coach_id::text);

-- Client-Coach relationship policies
CREATE POLICY "View client-coach relations" ON client_coach_relations
FOR SELECT USING (
  auth.uid()::text = client_id::text OR 
  auth.uid()::text = coach_id::text
);

CREATE POLICY "Coaches can create client relations" ON client_coach_relations
FOR INSERT WITH CHECK (auth.uid()::text = coach_id::text);

-- Workout assignment policies
CREATE POLICY "View workout assignments" ON workout_assignments
FOR SELECT USING (
  auth.uid()::text = client_id::text OR 
  auth.uid()::text = coach_id::text
);

CREATE POLICY "Coaches can create assignments" ON workout_assignments
FOR INSERT WITH CHECK (auth.uid()::text = coach_id::text);

-- Scheduled sessions policies
CREATE POLICY "View scheduled sessions" ON scheduled_sessions
FOR SELECT USING (
  auth.uid()::text = client_id::text OR 
  auth.uid()::text = coach_id::text
);

CREATE POLICY "Coaches can create sessions" ON scheduled_sessions
FOR INSERT WITH CHECK (auth.uid()::text = coach_id::text);

CREATE POLICY "Update own sessions" ON scheduled_sessions
FOR UPDATE USING (
  auth.uid()::text = client_id::text OR 
  auth.uid()::text = coach_id::text
);

-- Indexes for better performance
CREATE INDEX IF NOT EXISTS idx_workout_plans_coach_id ON workout_plans(coach_id);
CREATE INDEX IF NOT EXISTS idx_client_coach_relations_client_id ON client_coach_relations(client_id);
CREATE INDEX IF NOT EXISTS idx_client_coach_relations_coach_id ON client_coach_relations(coach_id);
CREATE INDEX IF NOT EXISTS idx_workout_assignments_client_id ON workout_assignments(client_id);
CREATE INDEX IF NOT EXISTS idx_workout_assignments_coach_id ON workout_assignments(coach_id);
CREATE INDEX IF NOT EXISTS idx_scheduled_sessions_client_id ON scheduled_sessions(client_id);
CREATE INDEX IF NOT EXISTS idx_scheduled_sessions_coach_id ON scheduled_sessions(coach_id);
CREATE INDEX IF NOT EXISTS idx_scheduled_sessions_date ON scheduled_sessions(scheduled_date);