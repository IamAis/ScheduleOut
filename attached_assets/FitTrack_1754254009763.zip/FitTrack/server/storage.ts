// Since we're using Supabase for data storage, this file is minimal
// All storage operations are handled via the Supabase client in the frontend

export interface IStorage {
  // Placeholder for any server-side storage operations if needed
}

export class SupabaseStorage implements IStorage {
  // Implementation would go here if needed for server-side operations
}

export const storage = new SupabaseStorage();
