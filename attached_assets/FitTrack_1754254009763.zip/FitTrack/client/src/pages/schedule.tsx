import { NavigationHeader } from '@/components/layout/navigation-header';
import { Sidebar } from '@/components/layout/sidebar';
import { ScheduleEditor } from '@/components/dashboard/schedule-editor';

export default function Schedule() {
  return (
    <div className="min-h-screen bg-neutral-50-custom">
      <NavigationHeader />
      
      <div className="flex">
        <Sidebar />
        
        <main className="flex-1 relative overflow-y-auto">
          <div className="py-6">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
              <div className="mb-8">
                <h1 className="text-3xl font-bold text-neutral-900-custom">Schedule</h1>
                <p className="mt-2 text-neutral-500-custom">
                  Manage your workout schedule and appointments
                </p>
              </div>

              <ScheduleEditor />
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}
