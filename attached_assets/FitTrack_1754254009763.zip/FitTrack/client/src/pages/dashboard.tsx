import { useSimpleAuth } from '@/contexts/simple-auth-context';
import { NavigationHeader } from '@/components/layout/navigation-header';
import { Sidebar } from '@/components/layout/sidebar';
import { StatsOverview } from '@/components/dashboard/stats-overview';
import { WorkoutPlansManager } from '@/components/dashboard/workout-plans-manager';
import { ScheduleEditor } from '@/components/dashboard/schedule-editor';
import { ClientsList } from '@/components/dashboard/clients-list';
import { QuickActions } from '@/components/dashboard/quick-actions';
import { UpcomingSessions } from '@/components/dashboard/upcoming-sessions';

export default function Dashboard() {
  const { userProfile } = useSimpleAuth();

  return (
    <div className="min-h-screen bg-neutral-50-custom">
      <NavigationHeader />
      
      <div className="flex">
        <Sidebar />
        
        <main className="flex-1 relative overflow-y-auto">
          <div className="py-6">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
              <div className="mb-8">
                <h1 className="text-3xl font-bold text-neutral-900-custom">
                  {userProfile?.role === 'coach' ? 'Coach Dashboard' : 'My Fitness Dashboard'}
                </h1>
                <p className="mt-2 text-neutral-500-custom">
                  {userProfile?.role === 'coach' 
                    ? 'Manage your clients and workout plans' 
                    : 'Track your progress and view assigned workouts'
                  }
                </p>
              </div>

              <StatsOverview />

              <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                <div className="lg:col-span-2 space-y-8">
                  {userProfile?.role === 'coach' && <WorkoutPlansManager />}
                  <ScheduleEditor />
                </div>

                <div className="space-y-8">
                  {userProfile?.role === 'coach' && <ClientsList />}
                  <QuickActions />
                  <UpcomingSessions />
                </div>
              </div>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}
