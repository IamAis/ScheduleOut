import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/lib/supabase';
import { useSimpleAuth } from '@/contexts/simple-auth-context';
import { NavigationHeader } from '@/components/layout/navigation-header';
import { Sidebar } from '@/components/layout/sidebar';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line, PieChart, Pie, Cell } from 'recharts';
import { TrendingUp, Users, Dumbbell, Calendar, Activity } from 'lucide-react';

export default function Analytics() {
  const { userProfile } = useSimpleAuth();

  // Mock data for demo purposes since this is a demo app
  const mockAnalyticsData = {
    monthlyWorkouts: [
      { month: 'Jan', workouts: 8, sessions: 12 },
      { month: 'Feb', workouts: 12, sessions: 18 },
      { month: 'Mar', workouts: 15, sessions: 22 },
      { month: 'Apr', workouts: 18, sessions: 28 },
      { month: 'May', workouts: 22, sessions: 35 },
      { month: 'Jun', workouts: 25, sessions: 40 },
    ],
    clientProgress: [
      { name: 'Active Clients', value: 8, color: '#8884d8' },
      { name: 'Completed Sessions', value: 156, color: '#82ca9d' },
      { name: 'Pending Sessions', value: 24, color: '#ffc658' },
    ],
    workoutDistribution: [
      { difficulty: 'Beginner', count: 12 },
      { difficulty: 'Intermediate', count: 18 },
      { difficulty: 'Advanced', count: 8 },
    ],
  };

  const statsCards = [
    {
      title: 'Total Clients',
      value: '24',
      change: '+12%',
      icon: Users,
      color: 'text-blue-600',
    },
    {
      title: 'Workout Plans',
      value: '38',
      change: '+8%',
      icon: Dumbbell,
      color: 'text-green-600',
    },
    {
      title: 'Sessions This Month',
      value: '156',
      change: '+24%',
      icon: Calendar,
      color: 'text-purple-600',
    },
    {
      title: 'Completion Rate',
      value: '94%',
      change: '+3%',
      icon: Activity,
      color: 'text-orange-600',
    },
  ];

  return (
    <div className="min-h-screen bg-neutral-50-custom">
      <NavigationHeader />
      
      <div className="flex">
        <Sidebar />
        
        <main className="flex-1 relative overflow-y-auto">
          <div className="py-6">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
              <div className="mb-8">
                <h1 className="text-3xl font-bold text-neutral-900-custom">Analytics</h1>
                <p className="mt-2 text-neutral-500-custom">
                  Track your coaching performance and client progress
                </p>
              </div>

              {/* Stats Cards */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
                {statsCards.map((stat) => {
                  const IconComponent = stat.icon;
                  return (
                    <Card key={stat.title}>
                      <CardContent className="p-6">
                        <div className="flex items-center justify-between">
                          <div>
                            <p className="text-sm font-medium text-neutral-500-custom">{stat.title}</p>
                            <p className="text-2xl font-bold text-neutral-900-custom">{stat.value}</p>
                            <p className="text-sm text-green-600">{stat.change} from last month</p>
                          </div>
                          <IconComponent className={`h-8 w-8 ${stat.color}`} />
                        </div>
                      </CardContent>
                    </Card>
                  );
                })}
              </div>

              {/* Charts */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
                {/* Monthly Workouts Chart */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <TrendingUp className="h-5 w-5" />
                      Monthly Activity
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ResponsiveContainer width="100%" height={300}>
                      <LineChart data={mockAnalyticsData.monthlyWorkouts}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="month" />
                        <YAxis />
                        <Tooltip />
                        <Line type="monotone" dataKey="workouts" stroke="#8884d8" strokeWidth={2} name="Workouts Created" />
                        <Line type="monotone" dataKey="sessions" stroke="#82ca9d" strokeWidth={2} name="Sessions Completed" />
                      </LineChart>
                    </ResponsiveContainer>
                  </CardContent>
                </Card>

                {/* Workout Distribution Chart */}
                <Card>
                  <CardHeader>
                    <CardTitle>Workout Difficulty Distribution</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ResponsiveContainer width="100%" height={300}>
                      <BarChart data={mockAnalyticsData.workoutDistribution}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="difficulty" />
                        <YAxis />
                        <Tooltip />
                        <Bar dataKey="count" fill="#8884d8" />
                      </BarChart>
                    </ResponsiveContainer>
                  </CardContent>
                </Card>
              </div>

              {/* Client Progress Overview */}
              <Card>
                <CardHeader>
                  <CardTitle>Client Activity Overview</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                    <div>
                      <h3 className="text-lg font-semibold mb-4">Recent Activity</h3>
                      <div className="space-y-4">
                        <div className="flex justify-between items-center p-3 bg-neutral-100-custom rounded">
                          <span>New client joined</span>
                          <span className="text-sm text-neutral-500-custom">2 hours ago</span>
                        </div>
                        <div className="flex justify-between items-center p-3 bg-neutral-100-custom rounded">
                          <span>Workout completed by John D.</span>
                          <span className="text-sm text-neutral-500-custom">4 hours ago</span>
                        </div>
                        <div className="flex justify-between items-center p-3 bg-neutral-100-custom rounded">
                          <span>New workout plan created</span>
                          <span className="text-sm text-neutral-500-custom">1 day ago</span>
                        </div>
                        <div className="flex justify-between items-center p-3 bg-neutral-100-custom rounded">
                          <span>Session rescheduled</span>
                          <span className="text-sm text-neutral-500-custom">2 days ago</span>
                        </div>
                      </div>
                    </div>
                    
                    <div>
                      <h3 className="text-lg font-semibold mb-4">Performance Metrics</h3>
                      <div className="space-y-4">
                        <div className="p-3 bg-neutral-100-custom rounded">
                          <div className="flex justify-between items-center mb-2">
                            <span>Client Retention Rate</span>
                            <span className="font-semibold">96%</span>
                          </div>
                          <div className="w-full bg-neutral-200 rounded-full h-2">
                            <div className="bg-green-600 h-2 rounded-full" style={{ width: '96%' }}></div>
                          </div>
                        </div>
                        
                        <div className="p-3 bg-neutral-100-custom rounded">
                          <div className="flex justify-between items-center mb-2">
                            <span>Session Completion Rate</span>
                            <span className="font-semibold">94%</span>
                          </div>
                          <div className="w-full bg-neutral-200 rounded-full h-2">
                            <div className="bg-blue-600 h-2 rounded-full" style={{ width: '94%' }}></div>
                          </div>
                        </div>
                        
                        <div className="p-3 bg-neutral-100-custom rounded">
                          <div className="flex justify-between items-center mb-2">
                            <span>Client Satisfaction</span>
                            <span className="font-semibold">4.8/5</span>
                          </div>
                          <div className="w-full bg-neutral-200 rounded-full h-2">
                            <div className="bg-purple-600 h-2 rounded-full" style={{ width: '96%' }}></div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}