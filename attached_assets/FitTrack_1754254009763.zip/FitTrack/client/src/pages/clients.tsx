import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/lib/supabase';
import { useSimpleAuth } from '@/contexts/simple-auth-context';
import { NavigationHeader } from '@/components/layout/navigation-header';
import { Sidebar } from '@/components/layout/sidebar';
import { Card, CardContent, CardHeader } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { UserPlus, Mail, Calendar, Dumbbell } from 'lucide-react';
import { ClientInviteModal } from '@/components/modals/client-invite-modal';

export default function Clients() {
  const { userProfile } = useSimpleAuth();
  const [showInviteModal, setShowInviteModal] = useState(false);

  const { data: clients, isLoading } = useQuery({
    queryKey: ['coach-clients-detailed', userProfile?.id],
    queryFn: async () => {
      if (!userProfile || userProfile.role !== 'coach') return [];

      const { data, error } = await supabase
        .from('client_coach_relations')
        .select(`
          *,
          users!client_coach_relations_clientId_fkey(id, firstName, lastName, email, createdAt)
        `)
        .eq('coachId', userProfile.id);

      if (error) throw error;

      // Get additional data for each client
      const clientsWithDetails = await Promise.all(
        (data || []).map(async (relation) => {
          const clientId = relation.users.id;

          // Get assigned workouts count
          const { data: workouts } = await supabase
            .from('workout_assignments')
            .select('id')
            .eq('clientId', clientId)
            .eq('coachId', userProfile.id);

          // Get last session
          const { data: lastSession } = await supabase
            .from('scheduled_sessions')
            .select('scheduledDate, completed')
            .eq('clientId', clientId)
            .eq('coachId', userProfile.id)
            .order('scheduledDate', { ascending: false })
            .limit(1)
            .single();

          // Get upcoming sessions count
          const { data: upcomingSessions } = await supabase
            .from('scheduled_sessions')
            .select('id')
            .eq('clientId', clientId)
            .eq('coachId', userProfile.id)
            .gte('scheduledDate', new Date().toISOString())
            .eq('completed', false);

          return {
            ...relation.users,
            relationId: relation.id,
            workoutCount: workouts?.length || 0,
            lastSession: lastSession?.scheduledDate ? new Date(lastSession.scheduledDate) : null,
            upcomingSessionsCount: upcomingSessions?.length || 0,
            isActive: lastSession ? new Date(lastSession.scheduledDate) > new Date(Date.now() - 7 * 24 * 60 * 60 * 1000) : false
          };
        })
      );

      return clientsWithDetails;
    },
    enabled: !!userProfile && userProfile.role === 'coach',
  });

  const getInitials = (firstName: string, lastName: string) => {
    return `${firstName.charAt(0)}${lastName.charAt(0)}`.toUpperCase();
  };

  const getLastWorkoutText = (lastSession: Date | null) => {
    if (!lastSession) return 'No sessions yet';
    
    const daysDiff = Math.floor((Date.now() - lastSession.getTime()) / (1000 * 60 * 60 * 24));
    
    if (daysDiff === 0) return 'Today';
    if (daysDiff === 1) return '1 day ago';
    return `${daysDiff} days ago`;
  };

  const getRandomColor = (index: number) => {
    const colors = [
      'bg-primary-custom',
      'bg-secondary-custom', 
      'bg-accent-custom',
      'bg-pink-500',
      'bg-purple-500',
      'bg-indigo-500'
    ];
    return colors[index % colors.length];
  };

  if (userProfile?.role !== 'coach') {
    return (
      <div className="min-h-screen bg-neutral-50-custom">
        <NavigationHeader />
        <div className="flex items-center justify-center h-screen">
          <Card>
            <CardContent className="p-6 text-center">
              <p className="text-neutral-500-custom">Access denied. Coach role required.</p>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-neutral-50-custom">
      <NavigationHeader />
      
      <div className="flex">
        <Sidebar />
        
        <main className="flex-1 relative overflow-y-auto">
          <div className="py-6">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
              <div className="mb-8">
                <div className="flex justify-between items-center">
                  <div>
                    <h1 className="text-3xl font-bold text-neutral-900-custom">My Clients</h1>
                    <p className="mt-2 text-neutral-500-custom">
                      Manage your client relationships and track their progress
                    </p>
                  </div>
                  <Button 
                    className="bg-secondary-custom text-white hover:bg-opacity-90"
                    onClick={() => setShowInviteModal(true)}
                  >
                    <UserPlus className="mr-2 h-4 w-4" />
                    Invite Client
                  </Button>
                </div>
              </div>

              {isLoading ? (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {[...Array(6)].map((_, i) => (
                    <Card key={i} className="animate-pulse">
                      <CardHeader>
                        <div className="flex items-center space-x-4">
                          <div className="w-12 h-12 bg-gray-200 rounded-full"></div>
                          <div className="space-y-2">
                            <div className="h-4 bg-gray-200 rounded w-24"></div>
                            <div className="h-3 bg-gray-200 rounded w-32"></div>
                          </div>
                        </div>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-2">
                          <div className="h-3 bg-gray-200 rounded"></div>
                          <div className="h-3 bg-gray-200 rounded w-2/3"></div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              ) : clients?.length === 0 ? (
                <Card className="text-center py-12">
                  <CardContent>
                    <div className="text-neutral-500-custom">
                      <UserPlus className="mx-auto h-12 w-12 mb-4" />
                      <h3 className="text-lg font-medium mb-2">No clients yet</h3>
                      <p>Start building your client base by inviting new clients!</p>
                    </div>
                  </CardContent>
                </Card>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {clients?.map((client, index) => (
                    <Card key={client.id} className="hover:shadow-lg transition-shadow">
                      <CardHeader className="pb-4">
                        <div className="flex items-center space-x-4">
                          <Avatar className={`w-12 h-12 ${getRandomColor(index)}`}>
                            <AvatarFallback className="text-white font-medium">
                              {getInitials(client.firstName, client.lastName)}
                            </AvatarFallback>
                          </Avatar>
                          <div className="flex-1">
                            <h3 className="text-lg font-semibold text-neutral-900-custom">
                              {client.firstName} {client.lastName}
                            </h3>
                            <div className="flex items-center text-sm text-neutral-500-custom">
                              <Mail className="h-3 w-3 mr-1" />
                              {client.email}
                            </div>
                          </div>
                          <div className={`w-3 h-3 rounded-full ${
                            client.isActive ? 'bg-accent-custom' : 'bg-neutral-300'
                          }`} title={client.isActive ? 'Active' : 'Inactive'}></div>
                        </div>
                      </CardHeader>
                      
                      <CardContent className="space-y-4">
                        <div className="grid grid-cols-2 gap-4">
                          <div className="text-center p-3 bg-neutral-50-custom rounded-lg">
                            <div className="flex items-center justify-center mb-1">
                              <Dumbbell className="h-4 w-4 text-primary-custom" />
                            </div>
                            <p className="text-2xl font-bold text-neutral-900-custom">{client.workoutCount}</p>
                            <p className="text-xs text-neutral-500-custom">Workouts</p>
                          </div>
                          
                          <div className="text-center p-3 bg-neutral-50-custom rounded-lg">
                            <div className="flex items-center justify-center mb-1">
                              <Calendar className="h-4 w-4 text-secondary-custom" />
                            </div>
                            <p className="text-2xl font-bold text-neutral-900-custom">{client.upcomingSessionsCount}</p>
                            <p className="text-xs text-neutral-500-custom">Upcoming</p>
                          </div>
                        </div>

                        <div className="space-y-2">
                          <div className="flex justify-between items-center">
                            <span className="text-sm text-neutral-500-custom">Last Session:</span>
                            <span className="text-sm font-medium text-neutral-900-custom">
                              {getLastWorkoutText(client.lastSession)}
                            </span>
                          </div>
                          
                          <div className="flex justify-between items-center">
                            <span className="text-sm text-neutral-500-custom">Member Since:</span>
                            <span className="text-sm font-medium text-neutral-900-custom">
                              {new Date(client.createdAt).toLocaleDateString('en-US', { 
                                month: 'short', 
                                year: 'numeric' 
                              })}
                            </span>
                          </div>
                        </div>

                        <div className="flex space-x-2 pt-2">
                          <Button variant="outline" size="sm" className="flex-1 text-primary-custom border-primary-custom hover:bg-primary-custom hover:text-white">
                            View Profile
                          </Button>
                          <Button variant="outline" size="sm" className="flex-1 text-secondary-custom border-secondary-custom hover:bg-secondary-custom hover:text-white">
                            Schedule
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
            </div>
          </div>
        </main>
      </div>
      
      <ClientInviteModal 
        isOpen={showInviteModal} 
        onClose={() => setShowInviteModal(false)} 
      />
    </div>
  );
}
