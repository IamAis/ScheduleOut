import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/lib/supabase';
import { useSimpleAuth } from '@/contexts/simple-auth-context';
import { NavigationHeader } from '@/components/layout/navigation-header';
import { Sidebar } from '@/components/layout/sidebar';
import { Card, CardContent, CardHeader } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Plus, Edit, Share2 } from 'lucide-react';

export default function Workouts() {
  const { userProfile } = useSimpleAuth();

  const { data: workouts, isLoading } = useQuery({
    queryKey: ['workouts', userProfile?.id],
    queryFn: async () => {
      if (!userProfile) return [];

      if (userProfile.role === 'coach') {
        // Get coach's workout plans
        const { data, error } = await supabase
          .from('workout_plans')
          .select('*')
          .eq('coachId', userProfile.id)
          .order('createdAt', { ascending: false });

        if (error) throw error;
        return data || [];
      } else {
        // Get client's assigned workouts
        const { data, error } = await supabase
          .from('workout_assignments')
          .select(`
            *,
            workout_plans(*),
            users!workout_assignments_coachId_fkey(firstName, lastName)
          `)
          .eq('clientId', userProfile.id);

        if (error) throw error;
        return data?.map(assignment => ({
          ...assignment.workout_plans,
          coachName: `${assignment.users.firstName} ${assignment.users.lastName}`,
          assignedAt: assignment.assignedAt
        })) || [];
      }
    },
    enabled: !!userProfile,
  });

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'beginner':
        return 'bg-accent-custom bg-opacity-10 text-accent-custom';
      case 'intermediate':
        return 'bg-neutral-100-custom text-neutral-500-custom';
      case 'advanced':
        return 'bg-primary-custom bg-opacity-10 text-primary-custom';
      default:
        return 'bg-neutral-100-custom text-neutral-500-custom';
    }
  };

  return (
    <div className="min-h-screen bg-neutral-50-custom">
      <NavigationHeader />
      
      <div className="flex">
        <Sidebar />
        
        <main className="flex-1 relative overflow-y-auto">
          <div className="py-6">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
              <div className="mb-8">
                <div className="flex justify-between items-center">
                  <div>
                    <h1 className="text-3xl font-bold text-neutral-900-custom">
                      {userProfile?.role === 'coach' ? 'Workout Plans' : 'My Workouts'}
                    </h1>
                    <p className="mt-2 text-neutral-500-custom">
                      {userProfile?.role === 'coach' 
                        ? 'Create and manage workout plans for your clients' 
                        : 'View your assigned workout plans'
                      }
                    </p>
                  </div>
                  {userProfile?.role === 'coach' && (
                    <Button className="bg-primary-custom text-white hover:bg-opacity-90">
                      <Plus className="mr-2 h-4 w-4" />
                      Create Workout Plan
                    </Button>
                  )}
                </div>
              </div>

              {isLoading ? (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {[...Array(6)].map((_, i) => (
                    <Card key={i} className="animate-pulse">
                      <CardHeader>
                        <div className="h-6 bg-gray-200 rounded w-3/4"></div>
                        <div className="h-4 bg-gray-200 rounded w-1/2"></div>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-2">
                          <div className="h-3 bg-gray-200 rounded"></div>
                          <div className="h-3 bg-gray-200 rounded w-2/3"></div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              ) : workouts?.length === 0 ? (
                <Card className="text-center py-12">
                  <CardContent>
                    <div className="text-neutral-500-custom">
                      <h3 className="text-lg font-medium mb-2">
                        {userProfile?.role === 'coach' ? 'No workout plans yet' : 'No workouts assigned yet'}
                      </h3>
                      <p>
                        {userProfile?.role === 'coach' 
                          ? 'Create your first workout plan to get started!' 
                          : 'Your coach will assign workouts soon.'
                        }
                      </p>
                    </div>
                  </CardContent>
                </Card>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {workouts?.map((workout) => (
                    <Card key={workout.id} className="hover:shadow-lg transition-shadow cursor-pointer">
                      <CardHeader>
                        <div className="flex justify-between items-start">
                          <div className="flex-1">
                            <h3 className="text-lg font-semibold text-neutral-900-custom">{workout.name}</h3>
                            <p className="text-sm text-neutral-500-custom mt-1">
                              {workout.exercises?.length || 0} exercises • {workout.duration} min
                            </p>
                            {userProfile?.role === 'client' && workout.coachName && (
                              <p className="text-xs text-neutral-500-custom mt-1">
                                Coach: {workout.coachName}
                              </p>
                            )}
                          </div>
                          {userProfile?.role === 'coach' && (
                            <div className="flex space-x-1">
                              <Button variant="ghost" size="sm" className="text-neutral-400 hover:text-neutral-600">
                                <Edit className="h-4 w-4" />
                              </Button>
                              <Button variant="ghost" size="sm" className="text-neutral-400 hover:text-primary-custom">
                                <Share2 className="h-4 w-4" />
                              </Button>
                            </div>
                          )}
                        </div>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-3">
                          {workout.description && (
                            <p className="text-sm text-neutral-600 line-clamp-2">{workout.description}</p>
                          )}
                          
                          <div className="flex items-center justify-between">
                            <Badge className={`text-xs px-2 py-1 rounded ${getDifficultyColor(workout.difficulty)}`}>
                              {workout.difficulty}
                            </Badge>
                            
                            <Button variant="outline" size="sm" className="text-primary-custom border-primary-custom hover:bg-primary-custom hover:text-white">
                              View Details
                            </Button>
                          </div>

                          {workout.exercises && workout.exercises.length > 0 && (
                            <div className="mt-3 pt-3 border-t border-gray-100">
                              <p className="text-xs text-neutral-500-custom mb-2">Exercises:</p>
                              <div className="space-y-1">
                                {workout.exercises.slice(0, 3).map((exercise: any, index: number) => (
                                  <div key={index} className="text-xs text-neutral-600">
                                    {exercise.name} - {exercise.sets}
                                  </div>
                                ))}
                                {workout.exercises.length > 3 && (
                                  <div className="text-xs text-neutral-500-custom">
                                    +{workout.exercises.length - 3} more exercises
                                  </div>
                                )}
                              </div>
                            </div>
                          )}
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}
