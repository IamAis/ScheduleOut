import { Link, useLocation } from 'wouter';
import { useSimpleAuth } from '@/contexts/simple-auth-context';
import { 
  Gauge, 
  Dumbbell, 
  Users, 
  Calendar, 
  TrendingUp 
} from 'lucide-react';

export function Sidebar() {
  const [location] = useLocation();
  const { userProfile } = useSimpleAuth();

  const isActive = (path: string) => location === path;

  const navItems = [
    { path: '/dashboard', icon: Gauge, label: 'Dashboard' },
    { path: '/workouts', icon: Dumbbell, label: userProfile?.role === 'coach' ? 'Workout Plans' : 'My Workouts' },
    ...(userProfile?.role === 'coach' ? [
      { path: '/clients', icon: Users, label: 'My Clients' }
    ] : []),
    { path: '/schedule', icon: Calendar, label: userProfile?.role === 'coach' ? 'Schedule Editor' : 'My Schedule' },
    ...(userProfile?.role === 'coach' ? [
      { path: '/analytics', icon: TrendingUp, label: 'Analytics' }
    ] : []),
  ];

  return (
    <aside className="hidden lg:flex lg:flex-shrink-0">
      <div className="flex flex-col w-64 bg-white border-r border-gray-200 h-screen sticky top-16">
        <div className="flex-1 flex flex-col min-h-0 pt-6 pb-4">
          <div className="flex-1 flex flex-col overflow-y-auto">
            <nav className="px-3 space-y-1">
              {navItems.map((item) => {
                const Icon = item.icon;
                return (
                  <Link key={item.path} href={item.path}>
                    <div
                      className={`group flex items-center px-3 py-2 text-sm font-medium rounded-lg cursor-pointer ${
                        isActive(item.path)
                          ? 'bg-primary-custom text-white'
                          : 'text-neutral-500-custom hover:bg-neutral-100-custom'
                      }`}
                    >
                      <Icon className="mr-3 h-5 w-5" />
                      {item.label}
                    </div>
                  </Link>
                );
              })}
            </nav>
          </div>
        </div>
      </div>
    </aside>
  );
}
