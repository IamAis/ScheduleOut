import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/lib/supabase';
import { useSimpleAuth } from '@/contexts/simple-auth-context';
import { Card, CardContent, CardHeader } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Plus, Edit, Share2, Dumbbell } from 'lucide-react';
import { WorkoutCreationModal } from '@/components/modals/workout-creation-modal';

export function WorkoutPlansManager() {
  const { userProfile } = useSimpleAuth();
  const [showCreateModal, setShowCreateModal] = useState(false);

  const { data: workoutPlans, isLoading } = useQuery({
    queryKey: ['workout-plans', userProfile?.id],
    queryFn: async () => {
      if (!userProfile || userProfile.role !== 'coach') return [];

      const { data, error } = await supabase
        .from('workout_plans')
        .select(`
          *,
          workout_assignments(client_id)
        `)
        .eq('coach_id', userProfile.id)
        .order('created_at', { ascending: false });

      if (error) throw error;

      // Count assignments for each workout plan
      return data.map(plan => ({
        ...plan,
        assignmentCount: plan.workout_assignments?.length || 0
      }));
    },
    enabled: !!userProfile && userProfile.role === 'coach',
  });

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'beginner':
        return 'bg-accent-custom bg-opacity-10 text-accent-custom';
      case 'intermediate':
        return 'bg-neutral-100-custom text-neutral-500-custom';
      case 'advanced':
        return 'bg-primary-custom bg-opacity-10 text-primary-custom';
      default:
        return 'bg-neutral-100-custom text-neutral-500-custom';
    }
  };

  if (userProfile?.role !== 'coach') return null;

  return (
    <>
      <Card className="shadow-sm border border-gray-200">
        <CardHeader className="px-6 py-4 border-b border-gray-200">
          <div className="flex justify-between items-center">
            <h2 className="text-xl font-semibold text-neutral-900-custom">Recent Workout Plans</h2>
            <Button 
              onClick={() => setShowCreateModal(true)}
              className="bg-primary-custom text-white hover:bg-opacity-90"
            >
              <Plus className="mr-2 h-4 w-4" />
              Create Plan
            </Button>
          </div>
        </CardHeader>
        <CardContent className="p-6">
          {isLoading ? (
            <div className="space-y-4">
              {[...Array(3)].map((_, i) => (
                <div key={i} className="animate-pulse border border-gray-200 rounded-lg p-4">
                  <div className="h-4 bg-gray-200 rounded w-1/3 mb-2"></div>
                  <div className="h-3 bg-gray-200 rounded w-1/2 mb-2"></div>
                  <div className="h-3 bg-gray-200 rounded w-1/4"></div>
                </div>
              ))}
            </div>
          ) : workoutPlans?.length === 0 ? (
            <div className="text-center py-8 text-neutral-500-custom">
              <Dumbbell className="mx-auto h-12 w-12 mb-4" />
              <p>No workout plans yet. Create your first one!</p>
            </div>
          ) : (
            <div className="space-y-4">
              {workoutPlans?.map((plan) => (
                <div
                  key={plan.id}
                  className="border border-gray-200 rounded-lg p-4 hover:border-primary-custom transition-colors cursor-pointer"
                >
                  <div className="flex justify-between items-start">
                    <div className="flex-1">
                      <h3 className="text-lg font-medium text-neutral-900-custom">{plan.name}</h3>
                      <p className="text-sm text-neutral-500-custom mt-1">
                        {plan.exercises?.length || 0} exercises • {plan.duration} min
                      </p>
                      <div className="flex items-center mt-2 space-x-4">
                        <Badge className={`text-xs px-2 py-1 rounded ${getDifficultyColor(plan.difficulty)}`}>
                          {plan.difficulty}
                        </Badge>
                        <span className="text-xs text-neutral-500-custom">
                          Assigned to {plan.assignmentCount} client{plan.assignmentCount !== 1 ? 's' : ''}
                        </span>
                      </div>
                    </div>
                    <div className="flex space-x-2">
                      <Button variant="ghost" size="sm" className="text-neutral-400 hover:text-neutral-600">
                        <Edit className="h-4 w-4" />
                      </Button>
                      <Button variant="ghost" size="sm" className="text-neutral-400 hover:text-primary-custom">
                        <Share2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      <WorkoutCreationModal 
        isOpen={showCreateModal} 
        onClose={() => setShowCreateModal(false)} 
      />
    </>
  );
}
