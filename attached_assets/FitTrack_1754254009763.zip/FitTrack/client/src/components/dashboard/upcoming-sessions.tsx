import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/lib/supabase';
import { useSimpleAuth } from '@/contexts/simple-auth-context';
import { Card, CardContent, CardHeader } from '@/components/ui/card';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';

export function UpcomingSessions() {
  const { userProfile } = useSimpleAuth();

  const { data: sessions, isLoading } = useQuery({
    queryKey: ['upcoming-sessions', userProfile?.id],
    queryFn: async () => {
      if (!userProfile) return [];

      const { data, error } = await supabase
        .from('scheduled_sessions')
        .select(`
          *,
          workout_plans(name),
          users!${userProfile.role === 'coach' ? 'scheduled_sessions_clientId_fkey' : 'scheduled_sessions_coachId_fkey'}(firstName, lastName)
        `)
        .eq(userProfile.role === 'coach' ? 'coachId' : 'clientId', userProfile.id)
        .gte('scheduledDate', new Date().toISOString())
        .eq('completed', false)
        .order('scheduledDate', { ascending: true })
        .limit(3);

      if (error) throw error;
      return data || [];
    },
    enabled: !!userProfile,
  });

  const getInitials = (firstName: string, lastName: string) => {
    return `${firstName.charAt(0)}${lastName.charAt(0)}`.toUpperCase();
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffDays = Math.floor((date.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));

    let dateText;
    if (diffDays === 0) {
      dateText = 'Today';
    } else if (diffDays === 1) {
      dateText = 'Tomorrow';
    } else {
      dateText = date.toLocaleDateString('en-US', { weekday: 'long' });
    }

    const timeText = date.toLocaleTimeString('en-US', { 
      hour: 'numeric', 
      minute: '2-digit',
      hour12: true 
    });

    return { dateText, timeText };
  };

  const getRandomColor = (index: number) => {
    const colors = [
      'bg-primary-custom',
      'bg-secondary-custom', 
      'bg-accent-custom',
      'bg-pink-500',
      'bg-purple-500',
      'bg-indigo-500'
    ];
    return colors[index % colors.length];
  };

  return (
    <Card className="shadow-sm border border-gray-200">
      <CardHeader className="px-6 py-4 border-b border-gray-200">
        <h2 className="text-lg font-semibold text-neutral-900-custom">Upcoming Sessions</h2>
      </CardHeader>
      <CardContent className="p-6">
        {isLoading ? (
          <div className="space-y-4">
            {[...Array(3)].map((_, i) => (
              <div key={i} className="flex items-center justify-between p-3 border border-gray-200 rounded-lg animate-pulse">
                <div className="flex items-center space-x-3">
                  <div className="w-8 h-8 bg-gray-200 rounded-full"></div>
                  <div>
                    <div className="h-4 bg-gray-200 rounded w-20 mb-1"></div>
                    <div className="h-3 bg-gray-200 rounded w-24"></div>
                  </div>
                </div>
                <div className="text-right">
                  <div className="h-3 bg-gray-200 rounded w-12 mb-1"></div>
                  <div className="h-3 bg-gray-200 rounded w-16"></div>
                </div>
              </div>
            ))}
          </div>
        ) : sessions?.length === 0 ? (
          <div className="text-center py-8 text-neutral-500-custom">
            <p>No upcoming sessions scheduled</p>
          </div>
        ) : (
          <div className="space-y-4">
            {sessions?.map((session, index) => {
              const { dateText, timeText } = formatDate(session.scheduledDate);
              const person = session.users;
              
              return (
                <div
                  key={session.id}
                  className="flex items-center justify-between p-3 border border-gray-200 rounded-lg hover:border-primary-custom transition-colors"
                >
                  <div className="flex items-center space-x-3">
                    <Avatar className={`w-8 h-8 ${getRandomColor(index)}`}>
                      <AvatarFallback className="text-white text-xs font-medium">
                        {getInitials(person.firstName, person.lastName)}
                      </AvatarFallback>
                    </Avatar>
                    <div>
                      <p className="text-sm font-medium text-neutral-900-custom">
                        {person.firstName} {person.lastName}
                      </p>
                      <p className="text-xs text-neutral-500-custom">
                        {session.workout_plans?.name}
                      </p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-xs font-medium text-neutral-900-custom">{dateText}</p>
                    <p className="text-xs text-neutral-500-custom">{timeText}</p>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
