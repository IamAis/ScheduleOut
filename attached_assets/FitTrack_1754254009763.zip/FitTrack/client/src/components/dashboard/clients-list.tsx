import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/lib/supabase';
import { useSimpleAuth } from '@/contexts/simple-auth-context';
import { Card, CardContent, CardHeader } from '@/components/ui/card';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Link } from 'wouter';

export function ClientsList() {
  const { userProfile } = useSimpleAuth();

  const { data: clients, isLoading } = useQuery({
    queryKey: ['coach-clients', userProfile?.id],
    queryFn: async () => {
      if (!userProfile || userProfile.role !== 'coach') return [];

      const { data, error } = await supabase
        .from('client_coach_relations')
        .select(`
          *,
          users!client_coach_relations_clientId_fkey(id, firstName, lastName, email)
        `)
        .eq('coachId', userProfile.id);

      if (error) throw error;

      // Get last workout for each client
      const clientsWithLastWorkout = await Promise.all(
        (data || []).map(async (relation) => {
          const { data: lastSession } = await supabase
            .from('scheduled_sessions')
            .select('scheduledDate, completed')
            .eq('clientId', relation.users.id)
            .eq('coachId', userProfile.id)
            .order('scheduledDate', { ascending: false })
            .limit(1)
            .single();

          return {
            ...relation.users,
            lastWorkout: lastSession?.scheduledDate ? new Date(lastSession.scheduledDate) : null,
            isActive: lastSession ? new Date(lastSession.scheduledDate) > new Date(Date.now() - 7 * 24 * 60 * 60 * 1000) : false
          };
        })
      );

      return clientsWithLastWorkout;
    },
    enabled: !!userProfile && userProfile.role === 'coach',
  });

  const getInitials = (firstName: string, lastName: string) => {
    return `${firstName.charAt(0)}${lastName.charAt(0)}`.toUpperCase();
  };

  const getLastWorkoutText = (lastWorkout: Date | null) => {
    if (!lastWorkout) return 'No workouts yet';
    
    const daysDiff = Math.floor((Date.now() - lastWorkout.getTime()) / (1000 * 60 * 60 * 24));
    
    if (daysDiff === 0) return 'Today';
    if (daysDiff === 1) return '1 day ago';
    return `${daysDiff} days ago`;
  };

  const getRandomColor = (index: number) => {
    const colors = [
      'bg-primary-custom',
      'bg-secondary-custom', 
      'bg-accent-custom',
      'bg-pink-500',
      'bg-purple-500',
      'bg-indigo-500'
    ];
    return colors[index % colors.length];
  };

  if (userProfile?.role !== 'coach') return null;

  return (
    <Card className="shadow-sm border border-gray-200">
      <CardHeader className="px-6 py-4 border-b border-gray-200">
        <div className="flex justify-between items-center">
          <h2 className="text-lg font-semibold text-neutral-900-custom">Recent Clients</h2>
          <Link href="/clients">
            <span className="text-primary-custom text-sm font-medium hover:text-opacity-80 cursor-pointer">
              View All
            </span>
          </Link>
        </div>
      </CardHeader>
      <CardContent className="p-6">
        {isLoading ? (
          <div className="space-y-4">
            {[...Array(4)].map((_, i) => (
              <div key={i} className="flex items-center space-x-3 animate-pulse">
                <div className="w-10 h-10 bg-gray-200 rounded-full"></div>
                <div className="flex-1">
                  <div className="h-4 bg-gray-200 rounded w-24 mb-1"></div>
                  <div className="h-3 bg-gray-200 rounded w-32"></div>
                </div>
                <div className="w-2 h-2 bg-gray-200 rounded-full"></div>
              </div>
            ))}
          </div>
        ) : clients?.length === 0 ? (
          <div className="text-center py-8 text-neutral-500-custom">
            <p>No clients yet. Start building your client base!</p>
          </div>
        ) : (
          <div className="space-y-4">
            {clients?.slice(0, 4).map((client, index) => (
              <div key={client.id} className="flex items-center space-x-3">
                <Avatar className={`w-10 h-10 ${getRandomColor(index)}`}>
                  <AvatarFallback className="text-white text-sm font-medium">
                    {getInitials(client.firstName, client.lastName)}
                  </AvatarFallback>
                </Avatar>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-neutral-900-custom truncate">
                    {client.firstName} {client.lastName}
                  </p>
                  <p className="text-xs text-neutral-500-custom">
                    Last workout: {getLastWorkoutText(client.lastWorkout)}
                  </p>
                </div>
                <div className={`w-2 h-2 rounded-full ${
                  client.isActive ? 'bg-accent-custom' : 'bg-neutral-300'
                }`}></div>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
