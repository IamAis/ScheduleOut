import { useState } from 'react';
import { useSimpleAuth } from '@/contexts/simple-auth-context';
import { Card, CardContent, CardHeader } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { 
  PlusCircle, 
  UserPlus, 
  BarChart3, 
  CalendarPlus, 
  ChevronRight 
} from 'lucide-react';
import { WorkoutCreationModal } from '@/components/modals/workout-creation-modal';
import { ClientInviteModal } from '@/components/modals/client-invite-modal';
import { SimpleSessionModal } from '@/components/modals/simple-session-modal';

export function QuickActions() {
  const { userProfile } = useSimpleAuth();
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [showInviteModal, setShowInviteModal] = useState(false);
  const [showSessionModal, setShowSessionModal] = useState(false);

  const coachActions = [
    {
      icon: PlusCircle,
      label: 'Create Workout',
      action: () => setShowCreateModal(true),
      color: 'text-primary-custom'
    },
    {
      icon: UserPlus,
      label: 'Invite Client',
      action: () => setShowInviteModal(true),
      color: 'text-secondary-custom'
    },
    {
      icon: BarChart3,
      label: 'View Analytics',
      action: () => console.log('View analytics'),
      color: 'text-accent-custom'
    },
    {
      icon: CalendarPlus,
      label: 'Schedule Session',
      action: () => setShowSessionModal(true),
      color: 'text-purple-500'
    }
  ];

  const clientActions = [
    {
      icon: PlusCircle,
      label: 'Log Workout',
      action: () => console.log('Log workout'),
      color: 'text-primary-custom'
    },
    {
      icon: BarChart3,
      label: 'View Progress',
      action: () => console.log('View progress'),
      color: 'text-accent-custom'
    },
    {
      icon: CalendarPlus,
      label: 'Book Session',
      action: () => console.log('Book session'),
      color: 'text-secondary-custom'
    }
  ];

  const actions = userProfile?.role === 'coach' ? coachActions : clientActions;

  return (
    <>
      <Card className="shadow-sm border border-gray-200">
        <CardHeader className="px-6 py-4 border-b border-gray-200">
          <h2 className="text-lg font-semibold text-neutral-900-custom">Quick Actions</h2>
        </CardHeader>
        <CardContent className="p-6">
          <div className="space-y-3">
            {actions.map((action, index) => {
              const Icon = action.icon;
              return (
                <Button
                  key={index}
                  variant="ghost"
                  className="w-full justify-between p-3 bg-neutral-50-custom hover:bg-neutral-100-custom h-auto"
                  onClick={action.action}
                >
                  <div className="flex items-center">
                    <Icon className={`${action.color} mr-3 h-5 w-5`} />
                    <span className="text-sm font-medium text-neutral-900-custom">{action.label}</span>
                  </div>
                  <ChevronRight className="text-neutral-400 h-4 w-4" />
                </Button>
              );
            })}
          </div>
        </CardContent>
      </Card>

      {userProfile?.role === 'coach' && (
        <>
          <WorkoutCreationModal 
            isOpen={showCreateModal} 
            onClose={() => setShowCreateModal(false)} 
          />
          <ClientInviteModal 
            isOpen={showInviteModal} 
            onClose={() => setShowInviteModal(false)} 
          />
          <SimpleSessionModal 
            isOpen={showSessionModal} 
            onClose={() => setShowSessionModal(false)} 
          />
        </>
      )}
    </>
  );
}
