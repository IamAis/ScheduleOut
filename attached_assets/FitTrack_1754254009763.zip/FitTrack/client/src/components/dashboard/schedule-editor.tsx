import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/lib/supabase';
import { useSimpleAuth } from '@/contexts/simple-auth-context';
import { Card, CardContent, CardHeader } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { ChevronLeft, ChevronRight, CalendarPlus } from 'lucide-react';
import { SimpleSessionModal } from '@/components/modals/simple-session-modal';

export function ScheduleEditor() {
  const { userProfile } = useSimpleAuth();
  const [currentDate, setCurrentDate] = useState(new Date());
  const [isSessionModalOpen, setIsSessionModalOpen] = useState(false);
  const [selectedDate, setSelectedDate] = useState<Date>();

  const { data: sessions } = useQuery({
    queryKey: ['scheduled-sessions', userProfile?.id, currentDate.getMonth(), currentDate.getFullYear()],
    queryFn: async () => {
      if (!userProfile) return [];

      const startOfMonth = new Date(currentDate.getFullYear(), currentDate.getMonth(), 1);
      const endOfMonth = new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 0);

      const { data, error } = await supabase
        .from('scheduled_sessions')
        .select(`
          *,
          workout_plans(name),
          users!scheduled_sessions_client_id_fkey(first_name, last_name)
        `)
        .eq(userProfile.role === 'coach' ? 'coach_id' : 'client_id', userProfile.id)
        .gte('scheduled_date', startOfMonth.toISOString())
        .lte('scheduled_date', endOfMonth.toISOString());

      if (error) throw error;
      return data || [];
    },
    enabled: !!userProfile,
  });

  const navigateMonth = (direction: 'prev' | 'next') => {
    setCurrentDate(prev => {
      const newDate = new Date(prev);
      if (direction === 'prev') {
        newDate.setMonth(prev.getMonth() - 1);
      } else {
        newDate.setMonth(prev.getMonth() + 1);
      }
      return newDate;
    });
  };

  const getDaysInMonth = () => {
    const year = currentDate.getFullYear();
    const month = currentDate.getMonth();
    const firstDay = new Date(year, month, 1);
    const lastDay = new Date(year, month + 1, 0);
    const daysInMonth = lastDay.getDate();
    const startingDayOfWeek = firstDay.getDay();

    const days = [];
    
    // Add empty cells for previous month
    for (let i = 0; i < startingDayOfWeek; i++) {
      const prevDate = new Date(year, month, 0 - startingDayOfWeek + i + 1);
      days.push({ date: prevDate, isCurrentMonth: false });
    }

    // Add current month days
    for (let day = 1; day <= daysInMonth; day++) {
      days.push({ date: new Date(year, month, day), isCurrentMonth: true });
    }

    return days;
  };

  const getSessionsForDate = (date: Date) => {
    if (!sessions) return [];
    return sessions.filter(session => {
      const sessionDate = new Date(session.scheduled_date);
      return sessionDate.toDateString() === date.toDateString();
    });
  };

  const handleDayClick = (date: Date) => {
    if (userProfile?.role === 'coach') {
      setSelectedDate(date);
      setIsSessionModalOpen(true);
    }
  };

  const monthNames = [
    'January', 'February', 'March', 'April', 'May', 'June',
    'July', 'August', 'September', 'October', 'November', 'December'
  ];

  const dayNames = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

  return (
    <Card className="shadow-sm border border-gray-200">
      <CardHeader className="px-6 py-4 border-b border-gray-200">
        <div className="flex justify-between items-center">
          <h2 className="text-xl font-semibold text-neutral-900-custom">Schedule Editor</h2>
          {userProfile?.role === 'coach' && (
            <Button 
              onClick={() => setIsSessionModalOpen(true)}
              className="bg-secondary-custom text-white hover:bg-opacity-90"
            >
              <CalendarPlus className="mr-2 h-4 w-4" />
              Add Session
            </Button>
          )}
        </div>
      </CardHeader>
      <CardContent className="p-6">
        {/* Calendar Header */}
        <div className="flex justify-between items-center mb-6">
          <h3 className="text-lg font-medium text-neutral-900-custom">
            {monthNames[currentDate.getMonth()]} {currentDate.getFullYear()}
          </h3>
          <div className="flex space-x-2">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => navigateMonth('prev')}
              className="p-2 text-neutral-400 hover:text-neutral-600"
            >
              <ChevronLeft className="h-4 w-4" />
            </Button>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => navigateMonth('next')}
              className="p-2 text-neutral-400 hover:text-neutral-600"
            >
              <ChevronRight className="h-4 w-4" />
            </Button>
          </div>
        </div>

        {/* Calendar Grid */}
        <div className="grid grid-cols-7 gap-1 mb-4">
          {dayNames.map(day => (
            <div key={day} className="text-center text-sm font-medium text-neutral-500-custom py-2">
              {day}
            </div>
          ))}
        </div>

        {/* Calendar Days */}
        <div className="grid grid-cols-7 gap-1">
          {getDaysInMonth().map((day, index) => {
            const dayName = day.date.getDate();
            const sessionsForDay = getSessionsForDate(day.date);
            const isToday = day.date.toDateString() === new Date().toDateString();

            return (
              <div
                key={index}
                onClick={() => handleDayClick(day.date)}
                className={`aspect-square border rounded p-1 cursor-pointer transition-colors ${
                  day.isCurrentMonth
                    ? isToday
                      ? 'border-primary-custom border-2 bg-primary-custom bg-opacity-10'
                      : 'border-gray-100 hover:bg-neutral-50-custom'
                    : 'border-gray-100'
                }`}
              >
                <div className={`text-sm font-medium ${
                  day.isCurrentMonth
                    ? isToday
                      ? 'text-primary-custom'
                      : 'text-neutral-900-custom'
                    : 'text-gray-300'
                }`}>
                  {dayName}
                </div>
                {sessionsForDay.length > 0 && (
                  <div className="mt-1 space-y-1">
                    {sessionsForDay.slice(0, 2).map((session, i) => (
                      <div
                        key={i}
                        className="w-2 h-2 bg-primary-custom rounded-full"
                        title={session.workout_plans?.name}
                      />
                    ))}
                    {sessionsForDay.length > 2 && (
                      <div className="text-xs text-neutral-500-custom">
                        +{sessionsForDay.length - 2}
                      </div>
                    )}
                  </div>
                )}
              </div>
            );
          })}
        </div>

        <SimpleSessionModal
          isOpen={isSessionModalOpen}
          onClose={() => setIsSessionModalOpen(false)}
          selectedDate={selectedDate}
        />
      </CardContent>
    </Card>
  );
}
