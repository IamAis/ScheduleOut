import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/lib/supabase';
import { useSimpleAuth } from '@/contexts/simple-auth-context';
import { Card, CardContent } from '@/components/ui/card';
import { Users, Dumbbell, CalendarCheck } from 'lucide-react';

export function StatsOverview() {
  const { userProfile } = useSimpleAuth();

  const { data: stats } = useQuery({
    queryKey: ['dashboard-stats', userProfile?.id],
    queryFn: async () => {
      if (!userProfile) return null;

      if (userProfile.role === 'coach') {
        // Get coach stats
        const [clientsResult, workoutsResult, sessionsResult] = await Promise.all([
          supabase
            .from('client_coach_relations')
            .select('*')
            .eq('coach_id', userProfile.id),
          supabase
            .from('workout_plans')
            .select('*')
            .eq('coach_id', userProfile.id),
          supabase
            .from('scheduled_sessions')
            .select('*')
            .eq('coach_id', userProfile.id)
            .gte('scheduled_date', new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString())
        ]);

        return {
          totalClients: clientsResult.data?.length || 0,
          activeWorkouts: workoutsResult.data?.length || 0,
          weekSessions: sessionsResult.data?.length || 0,
        };
      } else {
        // Get client stats
        const [assignmentsResult, sessionsResult] = await Promise.all([
          supabase
            .from('workout_assignments')
            .select('*')
            .eq('client_id', userProfile.id),
          supabase
            .from('scheduled_sessions')
            .select('*')
            .eq('client_id', userProfile.id)
            .gte('scheduled_date', new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString())
        ]);

        return {
          totalWorkouts: assignmentsResult.data?.length || 0,
          weekSessions: sessionsResult.data?.length || 0,
          completedSessions: sessionsResult.data?.filter(s => s.completed).length || 0,
        };
      }
    },
    enabled: !!userProfile,
  });

  if (!stats || !userProfile) return null;

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
      {userProfile.role === 'coach' ? (
        <>
          <Card className="overflow-hidden shadow-sm border border-gray-200">
            <CardContent className="p-6">
              <div className="flex items-center">
                <div className="flex-shrink-0">
                  <div className="w-12 h-12 bg-primary-custom bg-opacity-10 rounded-lg flex items-center justify-center">
                    <Users className="text-primary-custom h-6 w-6" />
                  </div>
                </div>
                <div className="ml-5 w-0 flex-1">
                  <dl>
                    <dt className="text-sm font-medium text-neutral-500-custom truncate">Total Clients</dt>
                    <dd className="text-2xl font-bold text-neutral-900-custom">{stats.totalClients}</dd>
                  </dl>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="overflow-hidden shadow-sm border border-gray-200">
            <CardContent className="p-6">
              <div className="flex items-center">
                <div className="flex-shrink-0">
                  <div className="w-12 h-12 bg-secondary-custom bg-opacity-10 rounded-lg flex items-center justify-center">
                    <Dumbbell className="text-secondary-custom h-6 w-6" />
                  </div>
                </div>
                <div className="ml-5 w-0 flex-1">
                  <dl>
                    <dt className="text-sm font-medium text-neutral-500-custom truncate">Active Workouts</dt>
                    <dd className="text-2xl font-bold text-neutral-900-custom">{stats.activeWorkouts}</dd>
                  </dl>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="overflow-hidden shadow-sm border border-gray-200">
            <CardContent className="p-6">
              <div className="flex items-center">
                <div className="flex-shrink-0">
                  <div className="w-12 h-12 bg-accent-custom bg-opacity-10 rounded-lg flex items-center justify-center">
                    <CalendarCheck className="text-accent-custom h-6 w-6" />
                  </div>
                </div>
                <div className="ml-5 w-0 flex-1">
                  <dl>
                    <dt className="text-sm font-medium text-neutral-500-custom truncate">This Week Sessions</dt>
                    <dd className="text-2xl font-bold text-neutral-900-custom">{stats.weekSessions}</dd>
                  </dl>
                </div>
              </div>
            </CardContent>
          </Card>
        </>
      ) : (
        <>
          <Card className="overflow-hidden shadow-sm border border-gray-200">
            <CardContent className="p-6">
              <div className="flex items-center">
                <div className="flex-shrink-0">
                  <div className="w-12 h-12 bg-primary-custom bg-opacity-10 rounded-lg flex items-center justify-center">
                    <Dumbbell className="text-primary-custom h-6 w-6" />
                  </div>
                </div>
                <div className="ml-5 w-0 flex-1">
                  <dl>
                    <dt className="text-sm font-medium text-neutral-500-custom truncate">Assigned Workouts</dt>
                    <dd className="text-2xl font-bold text-neutral-900-custom">{stats.totalWorkouts}</dd>
                  </dl>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="overflow-hidden shadow-sm border border-gray-200">
            <CardContent className="p-6">
              <div className="flex items-center">
                <div className="flex-shrink-0">
                  <div className="w-12 h-12 bg-secondary-custom bg-opacity-10 rounded-lg flex items-center justify-center">
                    <CalendarCheck className="text-secondary-custom h-6 w-6" />
                  </div>
                </div>
                <div className="ml-5 w-0 flex-1">
                  <dl>
                    <dt className="text-sm font-medium text-neutral-500-custom truncate">This Week Sessions</dt>
                    <dd className="text-2xl font-bold text-neutral-900-custom">{stats.weekSessions}</dd>
                  </dl>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="overflow-hidden shadow-sm border border-gray-200">
            <CardContent className="p-6">
              <div className="flex items-center">
                <div className="flex-shrink-0">
                  <div className="w-12 h-12 bg-accent-custom bg-opacity-10 rounded-lg flex items-center justify-center">
                    <CalendarCheck className="text-accent-custom h-6 w-6" />
                  </div>
                </div>
                <div className="ml-5 w-0 flex-1">
                  <dl>
                    <dt className="text-sm font-medium text-neutral-500-custom truncate">Completed Sessions</dt>
                    <dd className="text-2xl font-bold text-neutral-900-custom">{stats.completedSessions}</dd>
                  </dl>
                </div>
              </div>
            </CardContent>
          </Card>
        </>
      )}
    </div>
  );
}
