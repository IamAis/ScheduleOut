import { useState } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { format } from 'date-fns';
import { supabase } from '@/lib/supabase';
import { useSimpleAuth } from '@/contexts/simple-auth-context';
import { useToast } from '@/hooks/use-toast';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { CalendarIcon } from 'lucide-react';

const sessionSchema = z.object({
  workoutPlanId: z.string().min(1, 'Please select a workout plan'),
  clientId: z.string().min(1, 'Please select a client'),
  scheduledDate: z.string().min(1, 'Please select a date'),
  scheduledTime: z.string().min(1, 'Please select a time'),
});

type SessionFormData = z.infer<typeof sessionSchema>;

interface SessionCreationModalProps {
  isOpen: boolean;
  onClose: () => void;
  selectedDate?: Date;
}

export function SessionCreationModal({ isOpen, onClose, selectedDate }: SessionCreationModalProps) {
  const { userProfile } = useSimpleAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const form = useForm<SessionFormData>({
    resolver: zodResolver(sessionSchema),
    defaultValues: {
      workoutPlanId: '',
      clientId: '',
      scheduledDate: selectedDate ? format(selectedDate, 'yyyy-MM-dd') : format(new Date(), 'yyyy-MM-dd'),
      scheduledTime: '09:00',
    },
  });

  // Fetch coach's clients
  const { data: clients = [] } = useQuery({
    queryKey: ['coach-clients', userProfile?.id],
    queryFn: async () => {
      if (!userProfile || userProfile.role !== 'coach') return [];

      const { data, error } = await supabase
        .from('client_coach_relations')
        .select(`
          client_id,
          users!client_coach_relations_client_id_fkey(id, first_name, last_name, email)
        `)
        .eq('coach_id', userProfile.id);

      if (error) throw error;
      return data?.map(relation => relation.users).filter(Boolean) || [];
    },
    enabled: !!userProfile && userProfile.role === 'coach',
  });

  // Fetch coach's workout plans
  const { data: workoutPlans = [] } = useQuery({
    queryKey: ['coach-workout-plans', userProfile?.id],
    queryFn: async () => {
      if (!userProfile || userProfile.role !== 'coach') return [];

      const { data, error } = await supabase
        .from('workout_plans')
        .select('*')
        .eq('coach_id', userProfile.id)
        .order('name');

      if (error) throw error;
      return data || [];
    },
    enabled: !!userProfile && userProfile.role === 'coach',
  });

  const createSessionMutation = useMutation({
    mutationFn: async (data: SessionFormData) => {
      if (!userProfile) throw new Error('User not authenticated');

      const scheduledDateTime = new Date(`${data.scheduledDate}T${data.scheduledTime}`);

      const { error } = await supabase
        .from('scheduled_sessions')
        .insert({
          workout_plan_id: data.workoutPlanId,
          client_id: data.clientId,
          coach_id: userProfile.id,
          scheduled_date: scheduledDateTime.toISOString(),
        });

      if (error) throw error;
    },
    onSuccess: () => {
      toast({
        title: 'Session scheduled successfully!',
        description: 'The workout session has been added to the calendar.',
      });
      queryClient.invalidateQueries({ queryKey: ['scheduled-sessions'] });
      onClose();
      form.reset();
    },
    onError: (error: any) => {
      console.error('Session creation error:', error);
      toast({
        title: 'Failed to schedule session',
        description: error.message || 'Please try again.',
        variant: 'destructive',
      });
    },
  });

  const onSubmit = (data: SessionFormData) => {
    createSessionMutation.mutate(data);
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>Schedule New Session</DialogTitle>
        </DialogHeader>

        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="clientId"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Client</FormLabel>
                  <Select onValueChange={field.onChange} value={field.value}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Select a client" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {clients.map((client: any) => (
                        <SelectItem key={client.id} value={client.id}>
                          {client.first_name} {client.last_name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="workoutPlanId"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Workout Plan</FormLabel>
                  <Select onValueChange={field.onChange} value={field.value}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Select a workout plan" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {workoutPlans.map((plan: any) => (
                        <SelectItem key={plan.id} value={plan.id}>
                          {plan.name} ({plan.duration} min)
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="grid grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="scheduledDate"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Date</FormLabel>
                    <FormControl>
                      <Input type="date" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="scheduledTime"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Time</FormLabel>
                    <FormControl>
                      <Input type="time" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <div className="flex justify-end space-x-2 pt-4">
              <Button
                type="button"
                variant="outline"
                onClick={onClose}
                disabled={createSessionMutation.isPending}
              >
                Cancel
              </Button>
              <Button
                type="submit"
                disabled={createSessionMutation.isPending}
              >
                {createSessionMutation.isPending ? 'Scheduling...' : 'Schedule Session'}
              </Button>
            </div>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}