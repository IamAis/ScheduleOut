import { useState } from 'react';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { supabase } from '@/lib/supabase';
import { useSimpleAuth } from '@/contexts/simple-auth-context';
import { insertWorkoutPlanSchema } from '@shared/schema';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { Plus, Trash2 } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

const exerciseSchema = z.object({
  name: z.string().min(1, 'Exercise name is required'),
  sets: z.string().min(1, 'Sets are required'),
  rest: z.string().min(1, 'Rest time is required'),
});

const workoutFormSchema = z.object({
  name: z.string().min(1, 'Workout name is required'),
  description: z.string().optional(),
  duration: z.number().min(1, 'Duration must be at least 1 minute'),
  difficulty: z.enum(['beginner', 'intermediate', 'advanced']),
  exercises: z.array(exerciseSchema).min(1, 'At least one exercise is required'),
});

type WorkoutFormData = z.infer<typeof workoutFormSchema>;

interface WorkoutCreationModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function WorkoutCreationModal({ isOpen, onClose }: WorkoutCreationModalProps) {
  const { userProfile } = useSimpleAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [exercises, setExercises] = useState([
    { name: '', sets: '', rest: '' }
  ]);

  const form = useForm<WorkoutFormData>({
    resolver: zodResolver(workoutFormSchema),
    defaultValues: {
      name: '',
      description: '',
      duration: 45,
      difficulty: 'intermediate',
      exercises: [{ name: '', sets: '', rest: '' }],
    },
  });

  const createWorkoutMutation = useMutation({
    mutationFn: async (data: WorkoutFormData) => {
      // Create workout plan in localStorage for demo purposes
      const newWorkout = {
        id: crypto.randomUUID(),
        name: data.name,
        description: data.description || '',
        duration: data.duration,
        difficulty: data.difficulty,
        exercises: data.exercises,
        coach_id: userProfile!.id,
        created_at: new Date().toISOString(),
      };

      // Store in localStorage for demo
      const existingWorkouts = JSON.parse(localStorage.getItem('demo-workouts') || '[]');
      existingWorkouts.push(newWorkout);
      localStorage.setItem('demo-workouts', JSON.stringify(existingWorkouts));

      return newWorkout;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['workout-plans'] });
      toast({
        title: 'Success',
        description: 'Workout plan created successfully!',
      });
      onClose();
      form.reset();
      setExercises([{ name: '', sets: '', rest: '' }]);
    },
    onError: (error) => {
      toast({
        title: 'Error',
        description: 'Failed to create workout plan. Please try again.',
        variant: 'destructive',
      });
      console.error('Error creating workout:', error);
    },
  });

  const addExercise = () => {
    const newExercises = [...exercises, { name: '', sets: '', rest: '' }];
    setExercises(newExercises);
    form.setValue('exercises', newExercises);
  };

  const removeExercise = (index: number) => {
    if (exercises.length > 1) {
      const newExercises = exercises.filter((_, i) => i !== index);
      setExercises(newExercises);
      form.setValue('exercises', newExercises);
    }
  };

  const updateExercise = (index: number, field: keyof typeof exercises[0], value: string) => {
    const newExercises = [...exercises];
    newExercises[index][field] = value;
    setExercises(newExercises);
    form.setValue('exercises', newExercises);
  };

  const onSubmit = (data: WorkoutFormData) => {
    createWorkoutMutation.mutate(data);
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-screen overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Create Workout Plan</DialogTitle>
        </DialogHeader>

        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="name"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Workout Name</FormLabel>
                    <FormControl>
                      <Input placeholder="e.g., Upper Body Strength" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="duration"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Duration (minutes)</FormLabel>
                    <FormControl>
                      <Input 
                        type="number" 
                        placeholder="45" 
                        {...field}
                        onChange={(e) => field.onChange(parseInt(e.target.value) || 0)}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <FormField
              control={form.control}
              name="difficulty"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Difficulty Level</FormLabel>
                  <Select onValueChange={field.onChange} defaultValue={field.value}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Select difficulty" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="beginner">Beginner</SelectItem>
                      <SelectItem value="intermediate">Intermediate</SelectItem>
                      <SelectItem value="advanced">Advanced</SelectItem>
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="description"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Description</FormLabel>
                  <FormControl>
                    <Textarea 
                      placeholder="Brief description of the workout..."
                      rows={3}
                      {...field}
                      value={field.value || ''}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* Exercise List */}
            <div>
              <div className="flex justify-between items-center mb-4">
                <FormLabel>Exercises</FormLabel>
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={addExercise}
                  className="bg-neutral-100-custom text-neutral-700 hover:bg-neutral-200"
                >
                  <Plus className="mr-1 h-4 w-4" />
                  Add Exercise
                </Button>
              </div>

              <div className="space-y-3">
                {exercises.map((exercise, index) => (
                  <div key={index} className="border border-gray-200 rounded-lg p-4">
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                      <div>
                        <Input
                          placeholder="Exercise name"
                          value={exercise.name}
                          onChange={(e) => updateExercise(index, 'name', e.target.value)}
                        />
                      </div>
                      <div>
                        <Input
                          placeholder="Sets x Reps"
                          value={exercise.sets}
                          onChange={(e) => updateExercise(index, 'sets', e.target.value)}
                        />
                      </div>
                      <div className="flex items-center space-x-2">
                        <Input
                          placeholder="Rest (sec)"
                          value={exercise.rest}
                          onChange={(e) => updateExercise(index, 'rest', e.target.value)}
                        />
                        {exercises.length > 1 && (
                          <Button
                            type="button"
                            variant="ghost"
                            size="sm"
                            onClick={() => removeExercise(index)}
                            className="text-red-400 hover:text-red-600"
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="flex justify-end space-x-3 pt-4 border-t border-gray-200">
              <Button type="button" variant="outline" onClick={onClose}>
                Cancel
              </Button>
              <Button 
                type="submit" 
                disabled={createWorkoutMutation.isPending}
                className="bg-primary-custom text-white hover:bg-opacity-90"
              >
                {createWorkoutMutation.isPending ? 'Creating...' : 'Create Workout Plan'}
              </Button>
            </div>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
