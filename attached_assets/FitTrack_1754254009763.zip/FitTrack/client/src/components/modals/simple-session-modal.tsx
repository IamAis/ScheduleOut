import { useState } from 'react';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { format } from 'date-fns';
import { useSimpleAuth } from '@/contexts/simple-auth-context';
import { useToast } from '@/hooks/use-toast';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { CalendarIcon, Clock, Users } from 'lucide-react';

const sessionSchema = z.object({
  workoutName: z.string().min(1, 'Please select a workout'),
  clientName: z.string().min(1, 'Please select a client'),
  scheduledDate: z.string().min(1, 'Please select a date'),
  scheduledTime: z.string().min(1, 'Please select a time'),
});

type SessionFormData = z.infer<typeof sessionSchema>;

interface SimpleSessionModalProps {
  isOpen: boolean;
  onClose: () => void;
  selectedDate?: Date;
}

export function SimpleSessionModal({ isOpen, onClose, selectedDate }: SimpleSessionModalProps) {
  const { userProfile } = useSimpleAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Mock data for demo
  const mockWorkouts = [
    'Upper Body Strength',
    'Lower Body Power',
    'Cardio HIIT',
    'Full Body Circuit',
    'Core & Flexibility',
  ];

  const mockClients = [
    'John Smith',
    'Sarah Johnson',
    'Mike Davis',
    'Emily Wilson',
    'David Brown',
  ];

  const form = useForm<SessionFormData>({
    resolver: zodResolver(sessionSchema),
    defaultValues: {
      workoutName: '',
      clientName: '',
      scheduledDate: selectedDate ? format(selectedDate, 'yyyy-MM-dd') : '',
      scheduledTime: '09:00',
    },
  });

  const createSessionMutation = useMutation({
    mutationFn: async (data: SessionFormData) => {
      const newSession = {
        id: crypto.randomUUID(),
        workoutName: data.workoutName,
        clientName: data.clientName,
        scheduledDate: data.scheduledDate,
        scheduledTime: data.scheduledTime,
        coachId: userProfile!.id,
        status: 'scheduled',
        createdAt: new Date().toISOString(),
      };

      // Store in localStorage for demo
      const existingSessions = JSON.parse(localStorage.getItem('demo-sessions') || '[]');
      existingSessions.push(newSession);
      localStorage.setItem('demo-sessions', JSON.stringify(existingSessions));

      return newSession;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['scheduled-sessions'] });
      toast({
        title: 'Session Scheduled!',
        description: 'The workout session has been successfully scheduled.',
      });
      onClose();
      form.reset();
    },
    onError: (error) => {
      toast({
        title: 'Error',
        description: 'Failed to schedule session. Please try again.',
        variant: 'destructive',
      });
      console.error('Error creating session:', error);
    },
  });

  const onSubmit = (data: SessionFormData) => {
    createSessionMutation.mutate(data);
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <CalendarIcon className="h-5 w-5" />
            Schedule Session
          </DialogTitle>
        </DialogHeader>

        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="workoutName"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Workout Plan</FormLabel>
                  <Select onValueChange={field.onChange} value={field.value}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Select workout plan" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {mockWorkouts.map((workout) => (
                        <SelectItem key={workout} value={workout}>
                          {workout}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="clientName"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Client</FormLabel>
                  <Select onValueChange={field.onChange} value={field.value}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Select client" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {mockClients.map((client) => (
                        <SelectItem key={client} value={client}>
                          {client}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="grid grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="scheduledDate"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Date</FormLabel>
                    <FormControl>
                      <Input type="date" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="scheduledTime"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Time</FormLabel>
                    <FormControl>
                      <Input type="time" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <div className="flex justify-end gap-3 pt-4">
              <Button
                type="button"
                variant="outline"
                onClick={onClose}
                disabled={createSessionMutation.isPending}
              >
                Cancel
              </Button>
              <Button
                type="submit"
                disabled={createSessionMutation.isPending}
                className="bg-blue-600 hover:bg-blue-700"
              >
                {createSessionMutation.isPending ? (
                  <>
                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                    Scheduling...
                  </>
                ) : (
                  <>
                    <Clock className="h-4 w-4 mr-2" />
                    Schedule Session
                  </>
                )}
              </Button>
            </div>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}