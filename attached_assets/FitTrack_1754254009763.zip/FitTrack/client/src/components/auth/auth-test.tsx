import { useState } from 'react';
import { supabase } from '@/lib/supabase';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

export function AuthTest() {
  const [status, setStatus] = useState<string>('Ready to test');
  const [loading, setLoading] = useState(false);

  const testConnection = async () => {
    setLoading(true);
    setStatus('Testing connection...');
    try {
      const { data, error } = await supabase.auth.getSession();
      if (error) {
        setStatus(`Connection Error: ${error.message}`);
      } else {
        setStatus('✅ Supabase connection successful!');
      }
    } catch (err: any) {
      setStatus(`❌ Connection failed: ${err.message}`);
    }
    setLoading(false);
  };

  const testSignUp = async () => {
    setLoading(true);
    setStatus('Testing signup...');
    try {
      const { data, error } = await supabase.auth.signUp({
        email: 'test@example.com',
        password: 'testpassword123',
        options: {
          data: {
            first_name: 'Test',
            last_name: 'User',
            role: 'client'
          }
        }
      });
      
      if (error) {
        setStatus(`Signup Error: ${error.message}`);
      } else {
        setStatus('✅ Signup test successful! (Check your email for confirmation)');
      }
    } catch (err: any) {
      setStatus(`❌ Signup failed: ${err.message}`);
    }
    setLoading(false);
  };

  return (
    <Card className="max-w-md mx-auto mt-8">
      <CardHeader>
        <CardTitle>Supabase Connection Test</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="text-sm bg-gray-100 p-3 rounded">
          <strong>Status:</strong> {status}
        </div>
        
        <div className="space-y-2">
          <Button 
            onClick={testConnection} 
            disabled={loading}
            className="w-full"
            variant="outline"
          >
            Test Connection
          </Button>
          
          <Button 
            onClick={testSignUp} 
            disabled={loading}
            className="w-full"
          >
            Test Signup
          </Button>
        </div>
        
        <div className="text-xs text-gray-600">
          <p><strong>URL:</strong> https://zjnnfyocvlzpxscrjbcw.supabase.co</p>
          <p><strong>Key:</strong> {import.meta.env.VITE_SUPABASE_ANON_KEY ? '✅ Set' : '❌ Missing'}</p>
        </div>
      </CardContent>
    </Card>
  );
}