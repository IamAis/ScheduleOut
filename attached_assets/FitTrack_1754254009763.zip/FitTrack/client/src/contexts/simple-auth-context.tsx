import { createContext, useContext, useState, ReactNode } from 'react';

interface SimpleAuthContextType {
  user: { id: string; email: string } | null;
  userProfile: { id: string; email: string; firstName: string; lastName: string; role: 'coach' | 'client' } | null;
  login: (email: string, password: string) => Promise<void>;
  register: (email: string, password: string, firstName: string, lastName: string, role: 'coach' | 'client') => Promise<void>;
  logout: () => Promise<void>;
  loading: boolean;
}

const SimpleAuthContext = createContext<SimpleAuthContextType | undefined>(undefined);

export function SimpleAuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<{ id: string; email: string } | null>(null);
  const [userProfile, setUserProfile] = useState<{ id: string; email: string; firstName: string; lastName: string; role: 'coach' | 'client' } | null>(null);
  const [loading, setLoading] = useState(false); // Start as false for immediate load

  const login = async (email: string, password: string) => {
    // Simulate login
    setLoading(true);
    await new Promise(resolve => setTimeout(resolve, 500)); // Simulate API call
    
    const userId = crypto.randomUUID();
    const mockUser = { id: userId, email };
    const mockProfile = {
      id: userId,
      email,
      firstName: 'Demo',
      lastName: 'User',
      role: email.includes('coach') ? 'coach' as const : 'client' as const
    };
    
    setUser(mockUser);
    setUserProfile(mockProfile);
    setLoading(false);
  };

  const register = async (email: string, password: string, firstName: string, lastName: string, role: 'coach' | 'client') => {
    // Simulate registration
    setLoading(true);
    await new Promise(resolve => setTimeout(resolve, 500)); // Simulate API call
    
    const userId = crypto.randomUUID();
    const mockUser = { id: userId, email };
    const mockProfile = {
      id: userId,
      email,
      firstName,
      lastName,
      role
    };
    
    setUser(mockUser);
    setUserProfile(mockProfile);
    setLoading(false);
  };

  const logout = async () => {
    setUser(null);
    setUserProfile(null);
  };

  return (
    <SimpleAuthContext.Provider value={{
      user,
      userProfile,
      login,
      register,
      logout,
      loading,
    }}>
      {children}
    </SimpleAuthContext.Provider>
  );
}

export const useSimpleAuth = () => {
  const context = useContext(SimpleAuthContext);
  if (context === undefined) {
    throw new Error('useSimpleAuth must be used within a SimpleAuthProvider');
  }
  return context;
};