import { createContext, useContext, useEffect, useState, ReactNode } from 'react';
import { User } from '@supabase/supabase-js';
import { supabase } from '@/lib/supabase';
import { User as AppUser } from '@shared/schema';

interface AuthContextType {
  user: User | null;
  userProfile: AppUser | null;
  login: (email: string, password: string) => Promise<void>;
  register: (email: string, password: string, firstName: string, lastName: string, role: 'coach' | 'client') => Promise<void>;
  logout: () => Promise<void>;
  loading: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [userProfile, setUserProfile] = useState<AppUser | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let isMounted = true;

    const initializeAuth = async () => {
      try {
        // Get initial session
        const { data: { session } } = await supabase.auth.getSession();
        
        if (isMounted) {
          setUser(session?.user ?? null);
          if (session?.user) {
            await fetchUserProfile(session.user.id);
          }
          setLoading(false);
        }
      } catch (error) {
        console.error('Auth initialization error:', error);
        if (isMounted) {
          setLoading(false);
        }
      }
    };

    initializeAuth();

    // Listen for auth changes
    const { data: { subscription } } = supabase.auth.onAuthStateChange(async (event: string, session: any) => {
      if (isMounted) {
        setUser(session?.user ?? null);
        if (session?.user) {
          await fetchUserProfile(session.user.id);
        } else {
          setUserProfile(null);
        }
        setLoading(false);
      }
    });

    return () => {
      isMounted = false;
      subscription.unsubscribe();
    };
  }, []);

  const fetchUserProfile = async (userId: string) => {
    try {
      const { data, error } = await supabase
        .from('users')
        .select('*')
        .eq('id', userId)
        .single();
      
      if (error) {
        console.warn('Custom profile not found, using auth metadata:', error.message);
        // If custom profile doesn't exist, use auth metadata
        try {
          const { data: authUser } = await supabase.auth.getUser();
          if (authUser.user?.user_metadata) {
            setUserProfile({
              id: userId,
              email: authUser.user.email || '',
              password: '',
              firstName: authUser.user.user_metadata.first_name || 'User',
              lastName: authUser.user.user_metadata.last_name || '',
              role: authUser.user.user_metadata.role || 'client',
              createdAt: new Date()
            });
          }
        } catch (metaError) {
          console.error('Error fetching auth metadata:', metaError);
          // Create minimal profile
          setUserProfile({
            id: userId,
            email: '',
            password: '',
            firstName: 'User',
            lastName: '',
            role: 'client',
            createdAt: new Date()
          });
        }
        return;
      }
      setUserProfile(data);
    } catch (error) {
      console.error('Error fetching user profile:', error);
      // Create minimal profile to prevent loading loop
      setUserProfile({
        id: userId,
        email: '',
        password: '',
        firstName: 'User',
        lastName: '',
        role: 'client',
        createdAt: new Date()
      });
    }
  };

  const login = async (email: string, password: string) => {
    const { error } = await supabase.auth.signInWithPassword({
      email,
      password,
    });
    if (error) {
      console.error('Login error:', error);
      throw new Error(error.message || 'Login failed');
    }
  };

  const register = async (email: string, password: string, firstName: string, lastName: string, role: 'coach' | 'client') => {
    const { data, error } = await supabase.auth.signUp({
      email,
      password,
      options: {
        data: {
          first_name: firstName,
          last_name: lastName,
          role: role,
        }
      }
    });
    
    if (error) {
      console.error('Registration error:', error);
      throw new Error(error.message || 'Registration failed');
    }

    if (data.user) {
      // Try to create user profile in our custom table
      try {
        const { error: profileError } = await supabase
          .from('users')
          .insert({
            id: data.user.id,
            email,
            password: '', // We don't store passwords in our users table
            firstName: firstName,
            lastName: lastName,
            role,
          });
        
        if (profileError) {
          console.warn('Profile creation failed, but auth succeeded:', profileError);
        }
      } catch (err) {
        console.warn('Profile table not ready yet:', err);
      }
    }

  };

  const logout = async () => {
    const { error } = await supabase.auth.signOut();
    if (error) throw error;
  };

  return (
    <AuthContext.Provider value={{
      user,
      userProfile,
      login,
      register,
      logout,
      loading,
    }}>
      {children}
    </AuthContext.Provider>
  );
}

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
